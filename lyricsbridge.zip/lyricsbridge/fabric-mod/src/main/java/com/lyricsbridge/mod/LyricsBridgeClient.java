package com.lyricsbridge.mod;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

/**
 * Pregunta a la app Lyrics Bridge (127.0.0.1:8765, mismo celular) qué línea de letra suena
 * y la dibuja en el HUD. Opción por argumento JVM (Zalith -> Configuración -> Argumentos JVM):
 *   -Dlyricsbridge.url=http://127.0.0.1:8765/now?offset=300   (ms; negativo = atrasar)
 *   -Dlyricsbridge.mode=world|hud|both   (por defecto "world": letra flotando en el mundo)
 * Ajustes del modo mundo: ver WorldLyrics (distance, height, scale).
 */
public class LyricsBridgeClient implements ClientModInitializer {
    public static final String MOD_ID = "lyricsbridge";
    private static final String URL = System.getProperty("lyricsbridge.url", "http://127.0.0.1:8765/now");

    private record Now(boolean active, boolean playing, String title, String artist,
                       String prev, String line, String next) {
        static final Now NONE = new Now(false, false, "", "", "", "", "");
    }

    private static final String MODE = System.getProperty("lyricsbridge.mode", "world").toLowerCase();
    private static final boolean WORLD = !MODE.equals("hud");
    private static final boolean HUD_LINES = !MODE.equals("world");

    private static volatile Now now = Now.NONE;

    @Override
    public void onInitializeClient() {
        Thread t = new Thread(LyricsBridgeClient::pollLoop, "lyricsbridge-poll");
        t.setDaemon(true);
        t.start();

        // Título/artista (y las letras, si el modo incluye "hud") en pantalla
        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath(MOD_ID, "lyrics"), LyricsBridgeClient::extract);

        // Letra flotando en el mundo
        if (WORLD) {
            LevelRenderEvents.COLLECT_SUBMITS.register(ctx -> {
                Now n = now;
                if (!n.active() || !n.playing() || n.line().isEmpty()) {
                    WorldLyrics.reset();
                    return;
                }
                WorldLyrics.render(ctx, n.prev(), n.line(), n.next());
            });
        }
    }

    private static void pollLoop() {
        HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(1)).build();
        HttpRequest req = HttpRequest.newBuilder(URI.create(URL)).timeout(Duration.ofSeconds(1)).GET().build();
        while (true) {
            long sleep = 250;
            try {
                HttpResponse<String> res = http.send(req, HttpResponse.BodyHandlers.ofString());
                JsonObject o = JsonParser.parseString(res.body()).getAsJsonObject();
                if (bool(o, "active")) {
                    now = new Now(true, bool(o, "playing"), str(o, "title"), str(o, "artist"),
                            str(o, "prev"), str(o, "line"), str(o, "next"));
                } else {
                    now = Now.NONE;
                }
            } catch (Exception e) {
                now = Now.NONE;
                sleep = 2000; // la app no responde: reintenta más despacio
            }
            try {
                Thread.sleep(sleep);
            } catch (InterruptedException ie) {
                return;
            }
        }
    }

    private static boolean bool(JsonObject o, String k) {
        return o.has(k) && !o.get(k).isJsonNull() && o.get(k).getAsBoolean();
    }

    private static String str(JsonObject o, String k) {
        return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsString() : "";
    }

    private static void extract(GuiGraphicsExtractor g, DeltaTracker tracker) {
        Now n = now;
        if (!n.active() || !n.playing()) return;

        Minecraft mc = Minecraft.getInstance();
        Font font = mc.font;
        int w = mc.getWindow().getGuiScaledWidth();
        int h = mc.getWindow().getGuiScaledHeight();

        g.text(font, n.title() + " - " + n.artist(), 6, 6, 0xFFFFFFFF, true);

        if (!HUD_LINES) return;

        int y = h - 78; // sobre la barra de objetos
        centered(g, font, n.prev(), w / 2, y - 12, 0x99FFFFFF);
        centered(g, font, n.line(), w / 2, y, 0xFFFFFF55);
        centered(g, font, n.next(), w / 2, y + 12, 0x99FFFFFF);
    }

    private static void centered(GuiGraphicsExtractor g, Font font, String text, int cx, int y, int argb) {
        if (text == null || text.isEmpty()) return;
        g.text(font, text, cx - font.width(text) / 2, y, argb, true);
    }
}
