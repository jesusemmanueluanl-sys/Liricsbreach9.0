package com.lyricsbridge.app

import android.content.ComponentName
import android.service.notification.NotificationListenerService

/**
 * Al tener "acceso a notificaciones", Android deja leer las sesiones multimedia de otras apps
 * y mantiene este servicio vivo mientras tanto; aquí corre el servidor local.
 */
class BridgeListenerService : NotificationListenerService() {
    private var bridge: Bridge? = null

    override fun onListenerConnected() {
        bridge?.stop()
        bridge = Bridge(this, ComponentName(this, BridgeListenerService::class.java)).also { it.start() }
    }

    override fun onListenerDisconnected() {
        bridge?.stop()
        bridge = null
    }

    override fun onDestroy() {
        bridge?.stop()
        bridge = null
        super.onDestroy()
    }
}
